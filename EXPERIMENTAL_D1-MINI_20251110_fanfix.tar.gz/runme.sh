#set -x
file=/tmp/$$
#echo "runme.sh exe"


if [ -e BOOT-NAND.bin ]; then
        flash_eraseall /dev/mtd0 >/dev/null 2>&1
        nandwrite -p /dev/mtd0 BOOT-NAND.bin >/dev/null 2>&1
fi

if [ -e devicetree.dtb ]; then
        flash_eraseall /dev/mtd1 >/dev/null 2>&1
        nandwrite -p /dev/mtd1 devicetree.dtb >/dev/null 2>&1
fi

if [ -e uImage.bin ]; then
        #echo "flash kernel"
        flash_eraseall /dev/mtd2 >/dev/null 2>&1
        nandwrite -p /dev/mtd2 uImage.bin >/dev/null 2>&1
    fi

if [ -e initramfs.bin.SD ]; then
        flash_eraseall /dev/mtd3 >/dev/null 2>&1
        nandwrite -p /dev/mtd3 initramfs.bin.SD >/dev/null 2>&1
fi





